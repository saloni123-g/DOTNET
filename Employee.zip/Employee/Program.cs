﻿namespace Employee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello, World!");
            //Employee o1 = new Employee(1, "Amol", 20000, 10);
            //Console.WriteLine("1 S");
            //Employee o2 = new Employee(1, "Amol", 30000);
            //Console.WriteLine("2 S");
            //Employee o3 = new Employee(1, "Amol");
            //Console.WriteLine("3 S");
            //Employee o4 = new Employee(1);
            //Console.WriteLine("4 S");
            //Employee o5 = new Employee();
            //Console.WriteLine("5 S");

            //Employee o1 = new Employee( "Amol", 20000, 10);

            //Console.WriteLine("added emp 1");
            //o1.display();
            //Console.WriteLine(o1.GetNetSalary());
            //Employee o2 = new Employee( "Sania", 25000, 20);
            //o2.display();
            //Console.WriteLine("added emp 2");
            //Employee o3 = new Employee(null,15000, 5);
            //Console.WriteLine("added emp 3");
            //o3.display();

            Manager m = new Manager("dddd", 25000, 10, "asst manager");
            Console.WriteLine(m.GetNetSalary()); 
            m.display();
            m.Insert();
            Console.WriteLine("---------------------------------------------------------------------");
            GeneralManager gm = new GeneralManager("ggggg", 36000, 11, "senior gm", "hhh");
            Console.WriteLine(gm.GetNetSalary());
            gm.display();
            gm.Insert();



            Employee[] arrEmps=new Employee[5]; 
                

        }
    }

    public abstract class Employee:IDBFunctions
    {
        //string Name -> no blank names should be allowed
        //int EmpNo -> must be greater than 0
        //decimal Basic -> must be between some range
        //short DeptNo -> must be > 0

        private string name;

        public string Name
        {
           set{
                if (value != null)
                {
                    if (value != " ")
                    {
                        
                        name = value;
                    }
                   
                }
                else
                {
                    Console.WriteLine("no blank spaces");
                }
            }
            get
            {
                return name;
            }
        }


        public  static int empno=1;
        private static int Empno
        {
            get
            {
                return empno;
            }
            //set
            //{
               
            //}

        }
     //  private    decimal basic;

        public  abstract decimal Basic
        {


            get;
                
               
          
        }


       private  short deptno;
        public short DeptNo
        {
          
            set { 
                if(value <0)
                {
                    Console.WriteLine("department no should be greater than zero");

                }
                else
                {
                    deptno = value;
                }
               
            }
            get
            { 
            return deptno;
            }
        }

        public abstract decimal GetNetSalary();
        
       

        //string Name -> no blank names should be allowed
        //int EmpNo -> must be greater than 0
        //decimal Basic -> must be between some range
        //short DeptNo -> must be > 0

        public Employee( string name, decimal basic,short deptno )
        {
            empno = empno++;
            Name = name;
           
            DeptNo = deptno;
        }
        
        public void display()
        {
            Console.WriteLine(Empno + " " + Name + " " + Basic + " " + DeptNo);
        }

        void IDBFunctions.Insert()
        {
            Console.WriteLine("in employee insert");
        }

        void IDBFunctions.Update()
        {
            Console.WriteLine("in employee u[pdate");
        }

        void IDBFunctions.Delete()
        {
            Console.WriteLine("in employee delete");
        }
    }

    public interface IDBFunctions
    {
         void Insert();
        void Update();
        void Delete();
    }




    public class Manager : Employee, IDBFunctions 
    {
        private string designation;

      

        public string Designation
        {
            set
            {
                if(value!=" ")
                designation = value;
                else
                    Console.WriteLine("designation cant be blank");
            }
            get { return designation; }
        }
        public Manager(string name, decimal basic, short deptno, string designation) : base(name, basic, deptno)
        {
            Basic= basic;
            Designation = designation;
        }
        public override decimal Basic
        {
          
            get;
        }

        public void Delete()
        {
            Console.WriteLine("in manager delete");
        }

        public override decimal GetNetSalary()
        {
            decimal netsalary = Basic * 3;
            return netsalary;
        }

        public void Insert()
        {
            Console.WriteLine("in manager insert");
        }

        public void Update()
        {
            Console.WriteLine("in manager update");
        }
        public void display()
        {
            Console.WriteLine(empno + " " + Name + " " + Basic + " " + DeptNo + " " + Designation);
        }
    }






    public class GeneralManager : Manager, IDBFunctions
    {
        private string perks;

        

        public string Perks
        {
            set
            { perks = value; }
            get { return perks; }
        }

        public GeneralManager(string name, decimal basic, short deptno, string designation,string perks) : base(name, basic, deptno, designation)
        {
            Perks = perks;
        }

        public void display()
        {
            Console.WriteLine(empno + " " + Name + " " + Basic + " " + DeptNo + " " + Designation + " " +Perks);
        }
    }





    public class CEO : Employee, IDBFunctions
    {
        public CEO(string name, decimal basic, short deptno) : base(name, basic, deptno)
        {
        }

        public override decimal Basic
        {
            get;
        }

        public override sealed decimal GetNetSalary()
        {
           decimal netsalary=Basic * 4;
            return netsalary;
        }

        void IDBFunctions.Delete()
        {
            Console.WriteLine("in ceo delete");
        }

        void IDBFunctions.Insert()
        {
            Console.WriteLine("in ceo insert");
        }

        void IDBFunctions.Update()
        {
            Console.WriteLine("in ceo update");
        }
        public void display()
        {
            Console.WriteLine(empno + " " + Name + " " + Basic + " " + DeptNo);
        }
    }
}