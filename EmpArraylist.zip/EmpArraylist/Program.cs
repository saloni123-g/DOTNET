﻿using System.Collections;

namespace EmpArraylist
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");

            //  Employee e= new Employee(); 
            Employee[] arrEmps = new Employee[2];


            //for (int i = 0; i < arrEmps.Length; i++)
            //{



            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Name: ");
            //    string name = Console.ReadLine();

            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Salary: ");
            //    decimal basic = int.Parse(Console.ReadLine());

            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Department no: ");
            //    short deptno = short.Parse(Console.ReadLine());

            //    arrEmps[i] = new Employee(name,basic,deptno);

            //}
            //foreach(Employee emp in arrEmps)
            //{
            //    Console.WriteLine(emp);
            //}



            //Console.WriteLine("enter emp id");
            //int id=int.Parse(Console.ReadLine());   
            //for (int i = 0; i < arrEmps.Length; i++)
            //{
            //   /// if (id == Employee.Empno)
            //        Console.WriteLine(arrEmps[i]);
            //}

            ArrayList arr = new ArrayList();
            List<Employee> lstEmps = new List<Employee>();

            //for (int i = 0; i < arr.Count; i++)
            //{
           


            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Name: ");
            //    string name = Console.ReadLine();

            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Salary: ");
            //    decimal basic = int.Parse(Console.ReadLine());

            //    Console.WriteLine("");
            //    Console.WriteLine("Enter Department no: ");
            //    short deptno = short.Parse(Console.ReadLine());

            //    arr.Add(new Employee(name, basic, deptno)); 

            //}
            arr.Add(new Employee("vikram",65000,1));
            arr.Add(new Employee("neha", 28000, 1));
            arr.Add(new Employee("seema", 12000, 2));
            arr.Add(new Employee("aditya", 45000, 2));

            foreach (Employee emp in arr)
            {
                Console.WriteLine(emp);
            }

            arr.Sort();
            Console.WriteLine("--------------------------------------------");
            foreach (Employee emp in arr)
            {
                Console.WriteLine(emp);
            }

          
            Console.WriteLine(arr[arr.Count-1]);
            // Console.WriteLine("enter emp id");
            // int id = int.Parse(Console.ReadLine());
            //Employee e =(Employee)arr[id];
            // Console.WriteLine(e);
            //if(arr.Contains(id))
            //    Console.WriteLine("employree present");
            //Console.WriteLine("not found");
            // Console.WriteLine(arr.IndexOf(id));
            //Console.WriteLine("employeee presaent");
            //for (int i = 0; i < arr.Length; i++)
            //{
            //    if (arr.Contains(arr[i]))   
            //    Console.WriteLine(arrEmps[i]);
            //}

            //for (int i = 0; i < arr.Length; i++)
            //{

            //}
        }
        public class Employee:IComparable
        {
            //string Name -> no blank names should be allowed
            //int EmpNo -> must be greater than 0
            //decimal Basic -> must be between some range
            //short DeptNo -> must be > 0

            private string name;

            public string Name
            {
                set
                {
                    if (value != null)
                    {
                        if (value != " ")
                        {

                            name = value;
                        }

                    }
                    else
                    {
                        Console.WriteLine("no blank spaces");
                    }
                }
                get
                {
                    return name;
                }
            }


            private int empno;
            public int Empno
            {
                get
                {
                    return empno;
                }
                //set
                //{

                //}

            }
            private decimal basic;

            public decimal Basic
            {
                set
                {
                    if (value < 10000 && value > 70000)
                        Console.WriteLine("salary not in range");
                    basic = value;
                }
                get
                {
                    return basic;
                }


            }


            private short deptno;

            public short DeptNo
            {

                set
                {
                    if (value < 0)
                    {
                        Console.WriteLine("department no should be greater than zero");

                    }
                    else
                    {
                        deptno = value;
                    }

                }
                get
                {
                    return deptno;
                }
            }

            public decimal GetNetSalary()
            {
                decimal ns = Basic * 2;
                return ns;
            }



            //string Name -> no blank names should be allowed
            //int EmpNo -> must be greater than 0
            //decimal Basic -> must be between some range
            //short DeptNo -> must be > 0

            private static int e;
            public Employee(string name, decimal basic, short deptno)
            {
                empno = ++e;


                Name = name;
                Basic = basic;
                DeptNo = deptno;
            }




            public override string ToString()
            {
                return Empno + " " + Name + " " + Basic + " " + DeptNo;
            }

            public int CompareTo(object? obj)
            {
                Employee emp = obj as Employee; 
                return Basic.CompareTo(emp.Basic);
            }

            //public int CompareTo(Employee emp)
            //{
            //    if (this.Empno == emp.Empno)
            //        return 1;
            //    return 0;
            //}


        }


    }

}