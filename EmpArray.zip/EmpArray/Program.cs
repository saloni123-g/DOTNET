﻿
namespace EmpArray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            //  Employee e= new Employee(); 
            Employee[] arrEmps = new Employee[2];
            
            for (int i = 0; i < arrEmps.Length; i++)
            {
               


                Console.WriteLine("");
                Console.WriteLine("Enter Name: ");
                string name = Console.ReadLine();

                Console.WriteLine("");
                Console.WriteLine("Enter Salary: ");
                decimal basic = int.Parse(Console.ReadLine());

                Console.WriteLine("");
                Console.WriteLine("Enter Department no: ");
                short deptno = short.Parse(Console.ReadLine());

                arrEmps[i] = new Employee(name,basic,deptno);

            }
            foreach(Employee emp in arrEmps)
            {
                Console.WriteLine(emp);
            }


            Console.WriteLine("enter emp id");
            int id=int.Parse(Console.ReadLine());   
            for (int i = 0; i < arrEmps.Length; i++)
            {
                if (id == arrEmps[i].DeptNo)
                    Console.WriteLine(arrEmps[i]);
            }
        }
    }
    public  class Employee
    {
        //string Name -> no blank names should be allowed
        //int EmpNo -> must be greater than 0
        //decimal Basic -> must be between some range
        //short DeptNo -> must be > 0

        private string name;

        public string Name
        {
            set
            {
                if (value != null)
                {
                    if (value != " ")
                    {

                        name = value;
                    }

                }
                else
                {
                    Console.WriteLine("no blank spaces");
                }
            }
            get
            {
                return name;
            }
        }


        public static int empno;
        private static int Empno
        {
            get
            {
                return empno++;
            }
            //set
            //{

            //}

        }
         private    decimal basic;

        public  decimal Basic
        {
                 set { if(value<10000 && value>70000)
                    Console.WriteLine("salary not in range");
                basic = value;
            }
            get
            {
                return basic;
            }


        }


        private short deptno;
        
        public short DeptNo
        {

            set
            {
                if (value < 0)
                {
                    Console.WriteLine("department no should be greater than zero");

                }
                else
                {
                    deptno = value;
                }

            }
            get
            {
                return deptno;
            }
        }

        public  decimal GetNetSalary()
        {
            decimal ns = Basic * 2;
            return ns;
        }



        //string Name -> no blank names should be allowed
        //int EmpNo -> must be greater than 0
        //decimal Basic -> must be between some range
        //short DeptNo -> must be > 0

        public Employee(string name, decimal basic, short deptno)
        {
            empno = 0;
            empno=empno+1;
         
            Name = name;
            Basic = basic;
            DeptNo = deptno;
        }


        public void display()
        {
            Console.WriteLine(Empno + " " + Name + " " + Basic + " " + DeptNo);
        }

        public override string ToString()
        {
            return Empno + " " + Name + " " + Basic + " " + DeptNo;
        }

       


    }

    
}